#include <ros/ros.h>
#include <visualization_msgs/Marker.h>
#include <ros/console.h>
#include <nav_msgs/Odometry.h>
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <iostream>

// Defining location and threshold
double Threshold = 0.01;
double robot_x; 
double robot_y;
double Pick_LocationX  = -1;
double Pick_LocationY  =  7;
double Place_LocationX = -1;
double Place_LocationY = -4;
double pick_pos ;
double place_pos;

// Defining wait time in seconds
int Dwell      = 5;
int Curr_Dwell = 0;

// Call back function and sending robot position
void robotPoseCallback(const geometry_msgs::PoseWithCovarianceStamped::ConstPtr &msg_amcl)
{
  
  robot_x = msg_amcl->pose.pose.position.x;
  robot_y = msg_amcl->pose.pose.position.y;
}

int main(int argc, char **argv)
{
  ros::init(argc, argv, "basic_shapes");
  ros::NodeHandle n;
  ros::Publisher marker_pub = n.advertise<visualization_msgs::Marker>("visualization_marker", 1);

  int state = 0;
  uint32_t shape = visualization_msgs::Marker::CUBE;

  visualization_msgs::Marker marker;
  marker.header.frame_id = "map";
  marker.header.stamp = ros::Time::now();
  marker.ns = "basic_shapes";
  marker.id = 0;
  marker.type = shape;

 // colour --> Blue
  marker.color.r = 0.0f;
  marker.color.g = 0.0f;
  marker.color.b = 1.0f;
  marker.color.a = 1.0;
  marker.pose.position.z = 0;
  marker.lifetime = ros::Duration();

  // Marker position
  marker.pose.orientation.x = 0.0;
  marker.pose.orientation.y = 0.0;
  marker.pose.orientation.z = 0.0;
  marker.pose.orientation.w = 1.0;

  // Marker scale
  marker.scale.x = 0.4;
  marker.scale.y = 0.4;
  marker.scale.z = 0.4;

 
// Subscribe to /amcl_pose
  ros::Subscriber sub1 = n.subscribe("/amcl_pose", 1000, robotPoseCallback);

  while (ros::ok())
  {
    switch (state)
	{
      
      case 0:
	      // Calculating pick pos
	      pick_pos = abs(robot_x - Pick_LocationX) + abs(robot_y - Pick_LocationY);
	      if (pick_pos > Threshold)
	      {
		marker.action = visualization_msgs::Marker::ADD;
		marker.pose.position.x = Pick_LocationX;
		marker.pose.position.y = Pick_LocationY;
	      }
	      else
	      {
		state = 1;
		marker.action = visualization_msgs::Marker::DELETE;
	      }
	      //std::cout<<"case_0";
	      break;

      case 1:
	      if (Curr_Dwell  < Dwell)
	      {
		Curr_Dwell  += 1;
	      }
	      else
	      {
		state = 2;
	      }
	      //std::cout<<"case_1";
	      break;

      case 2:
	      // Calculating place pos
	      place_pos = abs(robot_x - Place_LocationX) + abs(robot_y - Place_LocationX);

	      if (place_pos > Threshold)
	      {
		marker.action = visualization_msgs::Marker::DELETE;
	      }
	      else
	      {
		marker.action = visualization_msgs::Marker::ADD;
		marker.pose.position.x = Place_LocationX;
		marker.pose.position.y = Place_LocationX;
	      }
	      //std::cout<<"case_2";
	      break;
  	}
    marker_pub.publish(marker);
    sleep(1);
    ros::spinOnce();
  }
}
