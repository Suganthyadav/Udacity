#include <ros/ros.h>
#include <visualization_msgs/Marker.h>

int main( int argc, char** argv )
{
  ros::init(argc, argv, "display_markers");
  ros::NodeHandle n;
  ros::Rate r(1);
  ros::Publisher marker_pub = n.advertise<visualization_msgs::Marker>("visualization_marker", 1);

  uint32_t shape = visualization_msgs::Marker::CUBE;
  visualization_msgs::Marker marker;
  marker.header.frame_id = "map";
  marker.header.stamp = ros::Time::now();
  marker.ns = "display_marker";
  marker.id = 0;
  marker.type = shape;
  marker.action = visualization_msgs::Marker::ADD;
// marker location
double Pick_LocationX  = -1;
double Pick_LocationY  =  7;
double Place_LocationX = -1;
double Place_LocationY = -4;

// marker scale
  marker.scale.x = 0.4;
  marker.scale.y = 0.4;
  marker.scale.z = 0.4;

// colour --> blue
  marker.color.r = 0.0f;
  marker.color.g = 0.0f;
  marker.color.b = 1.0f;
  marker.color.a = 1.0;

  marker.lifetime = ros::Duration();

  while (marker_pub.getNumSubscribers() < 1)
  {
    if (!ros::ok())
    {
      return 0;
    }
    ROS_WARN_ONCE("create a subscriber to the marker");
    sleep(1);
  }
  
  ROS_INFO("Show marker");
  marker_pub.publish(marker);
  marker.action = visualization_msgs::Marker::ADD;
  marker.pose.position.x = Pick_LocationX;
  marker.pose.position.y = Pick_LocationY;
  ros::Duration(5.0).sleep();
  
  ROS_INFO("Delete marker");
  marker.action = visualization_msgs::Marker::DELETE;
  marker_pub.publish(marker);
  ros::Duration(5.0).sleep();
  
  ROS_INFO("Show marker");
  marker.action = visualization_msgs::Marker::ADD;
  marker.pose.position.x = Place_LocationX;
  marker.pose.position.y = Place_LocationX;
  marker_pub.publish(marker);
  ros::Duration(5.0).sleep();
  ROS_INFO("completed");
  return 0;
  r.sleep(); 
}
