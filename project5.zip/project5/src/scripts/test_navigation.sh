#!/bin/sh
# TURTLEBOT_WORLD: deploys turtlebot in office environment
xterm  -e  "roslaunch turtlebot_gazebo turtlebot_world.launch world_file:=$(rospack find my_robot)/worlds/MyOffice.world" &
sleep 10

# GMAPPING_DEMO: SLAM
xterm  -e  "roslaunch turtlebot_gazebo amcl_demo.launch map_file:=$(rospack find my_robot)/maps/office.yaml" &
sleep 10

# NAVIGATION: Rviz
xterm  -e  "roslaunch turtlebot_rviz_launchers view_navigation.launch"
